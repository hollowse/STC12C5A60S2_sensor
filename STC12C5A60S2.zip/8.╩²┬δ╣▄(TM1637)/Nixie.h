#ifndef __Nixie_H_
#define __Nixie_H_

sbit CLK=P2^1;
sbit DIO=P2^0;

void start_IIC();
void stop_IIC();
void ack_IIC()   ;
void WriteByte(unsigned char WriteData) ;
void WSROM(unsigned char addr,unsigned char WData);
void disply_led(unsigned char qian,unsigned char bai,unsigned char shi,unsigned char ge);


#endif 