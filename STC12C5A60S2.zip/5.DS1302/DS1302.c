#include "STC12C5A60S2.h"
#include "intrins.h"
#include "stdio.h"
#include "DS1302.h"
#include "lcd12864.h"


unsigned char code read_addr[7]={0x81,0x83,0x85,0x87,0x89,0x8b,0x8d};
unsigned char code write_addr[7]={0x80,0x82,0x84,0x86,0x88,0x8a,0x8c};
unsigned char timer[]={0x55,0x59,0x23,0x26,0x5,0x04,0x22};		//�� �� ʱ �� �� �� ��

void WDS1302(unsigned char temp)
{
	unsigned char i;
	for(i=0;i<8;i++)
	{
		DS1302_SCK=0;
		DS1302_SDA=temp & 0x01;
		temp>>=1;
		DS1302_SCK=1;
	}
}
void WDS1302_Byte(unsigned char address,unsigned char dat)
{
	DS1302_RST=0; _nop_();
	DS1302_SCK=0;_nop_();
	DS1302_RST=1;_nop_();
	WDS1302(address);
	WDS1302(dat);
	DS1302_RST=0;
}
unsigned char RDS1302_Byte(unsigned char address)
{
	unsigned char i,temp=0x00;
	DS1302_RST=0;_nop_();
	DS1302_SCK=0;_nop_();
	DS1302_RST=1;_nop_();
	WDS1302(address);
	for(i=0;i<8;i++)
	{
		DS1302_SCK=0;
		temp>>=1;
		if(DS1302_SDA)
			temp|=0x80;
		DS1302_SCK=1;
	}
	DS1302_RST=0;_nop_();
	DS1302_SCK=0;
	_nop_();
	DS1302_SCK=1;_nop_();
	DS1302_SDA=0;_nop_();
	DS1302_SDA=1;_nop_();
	return (temp);
}

void ds1302_init()
{
	unsigned char i;
	WDS1302_Byte(0x8e,0x00);
	for(i=0;i<7;i++)
	{
		WDS1302_Byte(write_addr[i],timer[i]);
	}
		WDS1302_Byte(0x8e,0x80);
}
void ds1302_read()
{
	unsigned char i;

	for(i=0;i<7;i++)
	{
		timer[i]=RDS1302_Byte(read_addr[i]);
	}
}