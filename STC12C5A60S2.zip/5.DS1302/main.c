#include <STC12C5A60S2.h>
#include <stdio.h>
#include "intrins.h"
#include "delay.h"
#include "lcd12864.h"
#include "DS1302.h"
uint second,min,hour;
uchar s[8];

void main()
{
	PSB = 0;
	lcdinit();
	ds1302_init();			//�ڶ����ճ���ʱ������ע�ʹ˾䣬ʱ�ӻ���籣��
	delay1ms(10);
	
	while(1)
	{
		ds1302_read();
		second = (int)BCDTODEC(timer[0]);
		min = (int)BCDTODEC(timer[1]);	
		hour = (int)BCDTODEC(timer[2]);
		
		sprintf(s,"%d:%d:%d",hour,min,second);
		dis (1,0,s);		if (second == 0)	write_com(0x01);
		dis (2,1,"ʱ��");
	}
}

