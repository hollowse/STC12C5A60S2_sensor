
#include"delay.h"


/*-------------------------
 uS��ʱ����
 --------------------------*/
void DelayUs2x(unsigned char t)
{   
    while(--t);
}

/*--------------------------
 mS��ʱ����
----------------------------*/
void DelayMs(unsigned char t)
{
    while(t--)
    {
        //������ʱ1mS
        DelayUs2x(245);
        DelayUs2x(245);
    }
}

   

