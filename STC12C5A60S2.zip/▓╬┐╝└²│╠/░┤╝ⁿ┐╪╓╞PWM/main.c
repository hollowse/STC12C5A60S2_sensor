#include <reg52.h>
typedef unsigned char uchar;
typedef unsigned int uint;

sbit Key1=P3^0;
sbit Key2=P3^1;
sbit PWM=P1^0;
uchar  code table[]={0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f,0x77,0x7c,0x39,0x5e,0x79,0x71};
uchar count,time,i;

void delayms(uint k)
{
        uint i,j;
        for(i=k;i>0;i--)
                for(j=110;j>0;j--);
}
void Timer0Init()                //100΢��@12.000MHz
{
        TMOD |= 0x02;                //���ö�ʱ��ģʽ
        TL0 = 0x9C;                //���ö�ʱ��ֵ
        TH0 = 0x9C;                //���ö�ʱ����ֵ
        TF0 = 0;                //���TF0��־
        TR0 = 1;                //��ʱ��0��ʼ��ʱ
        EA=1;
        ET0=1;
}
void display()
{
        static bit num=0;
        P0 = 0x00;
        if(num)
        {
                P2=~0xfe;
                P0=table[i/10];
                num=~num;
        }
        else
        {
                P2=~0xfd;
                P0=table[i%10];
                num=~num;
        }
}

void main( )
{
        Timer0Init();       
        count=99;
        i=100-count;
        while(1)
        {
          if(!Key1)   //
            {
             delayms(10);
             if(!Key1)
               {
                 if(count>1)
                    count--;               
                    while(!Key1);
                    i=100-count;
                }
             }
          if(!Key2)
           {
             delayms(10);
              if(!Key2)
                {
                 if(count<99)
                    count++;               
                   while(!Key2);
                   i=100-count;
                 }
           }
       }
}
void timer0() interrupt        1  
{
        time++;
        if(count>=time)
                PWM=1;
        else   PWM=0;
        if(time>99)
                time=0;
        if(time%10==0)
                display();
}