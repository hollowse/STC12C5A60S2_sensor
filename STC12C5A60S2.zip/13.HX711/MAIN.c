#include <STC12C5A60S2.h>
#include <intrins.h>
#include "delay.h"
#include <stdio.h>
#include "LCD12864.h"
#include "HX711.h"

uint s[10];
uint weight;

void main()
{
	PSB = 0;
	lcdinit();
	delay1ms(1);
	
	while(1)
	{
		weight = HX711_Read();
		sprintf(s,"������%d",weight);
		dis (2,1,s);
	}
}

