#ifndef __delay_H_
#define __delay_H_

void delay1ms(unsigned char x);		//@11.0592MHz



#endif 