#include <STC12C5A60S2.H>
#include "intrins.h"



void UartInit(void)		//9600bps@11.0592MHz
{
	PCON &= 0x7F;		//??????
	SCON = 0x50;		//8???,?????
	AUXR |= 0x04;		//?????1T??
	BRT = 0xDC;			//???????
	AUXR |= 0x01;
	AUXR |= 0x10;		
}

void outchar(char ch)
{
	SBUF = ch;
	while(!TI);TI = 0;
}

void prints(char *s)
{
	while(*s != '\0')
	{
		SBUF = *s++;
		while(!TI);
		TI = 0;
	}
}

