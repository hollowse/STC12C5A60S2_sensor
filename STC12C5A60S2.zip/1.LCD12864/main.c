#include <STC12C5A60S2.h>
#include <intrins.h>
#include "delay.h"
#include "LCD12864.h"


void Main()
{ 
	PSB = 0;
	lcdinit();
	delay1ms(1);
	
	cartoon();

	while(1)
	{
			Test();

	}
}
