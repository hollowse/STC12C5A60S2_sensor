#ifndef __matrixkey_H_
#define __matrixkey_H_

unsigned char key_scan();

#endif 