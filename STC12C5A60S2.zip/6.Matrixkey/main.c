#include <STC12C5A60S2.h>
#include <stdio.h>
#include <math.h>
#include <intrins.h>
#include "delay.h"
#include "LCD12864.h"
#include "matrixkey.h"

uint key_value = 1;
uchar s[16],flag;		//������־λ

void Main()
{
	PSB = 0;
	lcdinit();
	delay1ms(1);
	while(1)
	{
		flag = key_value;
		
		key_value = key_scan();
		sprintf(s,"%d",key_value);
		
		if (flag != key_value)		write_com(0x01);

		dis (1,0,s);
		dis (2,1,"�������");
	}
}
