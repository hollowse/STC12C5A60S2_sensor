#ifndef __ADC_H_
#define __ADC_H_

void AD_init();
unsigned int Get_AD(unsigned int ch);
unsigned int temp(uint x);
unsigned int light(uint x);	

#endif