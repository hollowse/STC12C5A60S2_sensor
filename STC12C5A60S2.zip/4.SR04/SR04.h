#ifndef __SR04_H_
#define __SR04_H_

sbit trig = P2^0;
sbit echo = P2^1;

void SR04_init();
void timer0_init();
void Conut();
void SR04_data();


#endif 