#include <reg52.h>
#include <intrins.h>
#include "delay.h"
#include "LCD12864.h"
#include "SR04.h"
void main()
{
	PSB = 0;
	lcdinit();
	EA = 1;
	timer0_init();
	delay1ms(1);
	
	while(1)
	{
		SR04_data();
		dis (1,3,"       ");
	}
}