#include <STC12C5A60S2.H>
#include "intrins.h"
#include <stdio.h>
#include "LCD12864.h"
#include "delay.h"
#include "motor.h"
#include "Matrixkey.h"


void main()
{
	PSB = 0;
	lcdinit();
	Timer1_Init();
	delay1ms(1);
	delay100us(1);
	
	while(1)
	{
			
			dis (2,2,"�������");
	}		
}


