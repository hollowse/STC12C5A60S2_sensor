#ifndef __HX711_H_
#define __HX711_H_


sbit HX711_DOUT=P2^1; 
sbit HX711_SCK=P2^0; 

unsigned int HX711_Read();


#endif 