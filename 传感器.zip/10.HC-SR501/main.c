#include <STC12C5A60S2.h>
#include <intrins.h>
#include "delay.h"
#include "LCD12864.h"


void main()
{
	PSB = 0;
	lcdinit();
	
	delay(10);
	
	
	while(1)
	{
		
		HC_SR501_check();
		
	}
	
}

