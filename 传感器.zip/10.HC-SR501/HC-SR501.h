#ifndef __HC_SR501_H_
#define __HC_SR501_H_

void HC_SR501_check();


#endif 