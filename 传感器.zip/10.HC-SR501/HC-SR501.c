#include <STC12C5A60S2.h>
#include <intrins.h>
#include "delay.h"
#include "lcd12864.h"


sbit HC_SR501 = P3^7;
sbit buzzer = P3^6;

void HC_SR501_check()
{
	if (HC_SR501 == 1)
	{
//		buzzer = 1;
		dis (1,1,"����");
	}
	else 
	{
		buzzer = 0;
		dis (1,1,"����");
	}
	
	
}