#include <STC12C5A60S2.H>
#include "intrins.h"
#include "delay.h"
#include "lcd12864.h"

sbit buzzer = P2^0;
sbit light = P3^7;

void main()
{
	PSB = 0;
	lcdinit();
	delay(10);
	while(1)
	{
		if (light == 0)
		{
			dis (2,1,"��");
			buzzer = 0;
		}
		else 
		{	
			dis (2,1,"��");
			buzzer = 1;
		}		
		
		delay1ms (10);			

	}
	
	
}