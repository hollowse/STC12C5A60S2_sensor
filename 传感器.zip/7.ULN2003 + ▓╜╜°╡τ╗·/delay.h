#ifndef __delay_H_
#define __delay_H_

#define uchar unsigned char
#define uint unsigned int

void delay1ms(unsigned char x);		//@11.0592MHz
void delay(unsigned char x);
void delay100us(unsigned char x);		//@11.0592MHz


#endif