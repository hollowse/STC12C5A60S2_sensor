#include <STC12C5A60S2.H>
#include "delay.h"
#include "motor.h"
#include "intrins.h"
#include "Matrixkey.h"


unsigned char d = 0;		//�����λ��־λ��
unsigned char x;
uchar count,flag;

uchar time[2][3] = { {0xCD,0X71,0X66}, {0XD4,0XDD,0XEA} }	;	//TH1,TL1	��ʱ��ʱ�䣺1ms��800us��500us����Ӧ���������λ

void Timer1_Init(void)		//1??@11.0592MHz
{
	AUXR |= 0x40;
	TMOD &= 0x0F;	
	TL1 = time[0][d];
	TH1 = time[1][d];
	TF1 = 0;		
	TR1 = 1;			
	ET1 = 1;	
	EA = 1;	
}

void zheng()						//��ת
{
	switch(x)
	{
		case 0 :	A1=1; B1=0; C1=0; D1=0;		break;
		case 1 :	A1=1; B1=1; C1=0; D1=0;		break;
		case 2 :	A1=0; B1=1; C1=0; D1=0;		break;
		case 3 :	A1=0; B1=1; C1=1; D1=0;		break;
		case 4 :	A1=0; B1=0; C1=1; D1=0;		break;
		case 5 :	A1=0; B1=0; C1=1; D1=1;		break;
		case 6 :	A1=0; B1=0; C1=0; D1=1;		break;
		case 7 :	A1=1; B1=0; C1=0; D1=1;		break;
	}
	x ++;		if (x > 7)		x = 0;
}

void dao()							//��ת
{
	switch(x)
	{
		case 0 :	A1=1; B1=0; C1=0; D1=1;		break;
		case 1 :	A1=0; B1=0; C1=0; D1=1;		break;
		case 2 :	A1=0; B1=0; C1=1; D1=1;		break;
		case 3 :	A1=0; B1=0; C1=1; D1=0;		break;
		case 4 :	A1=0; B1=1; C1=1; D1=0;		break;
		case 5 :	A1=0; B1=1; C1=0; D1=0;		break;
		case 6 :	A1=1; B1=1; C1=0; D1=0;		break;
		case 7 :	A1=1; B1=0; C1=0; D1=0;		break;
	}
	x ++;		if (x > 7)		x = 0;
}

void Timer1_Isr(void) interrupt 3
{	

	TL1 = time[d][1];
	TH1 = time[d][0];
	count ++;
	flag = key_scan();					//�������s1���£������ת���˳���ľ�����̽�����һ������
	
	if (count > 50)
	{
		if (flag == 0)		zheng();			//��ת
		else 	if (flag == 1)	dao();		//��ת
	}
	
	if (count > 100)		count = 0;
}
