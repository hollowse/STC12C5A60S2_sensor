#include <STC12C5A60S2.H>
#include "intrins.h"


void delay1ms(unsigned char x)		//@11.0592MHz
{
	unsigned char i, j;
	while(x --)
	{
	_nop_();
	i = 11;
	j = 190;
	do
	{
		while (--j);
	} while (--i);
	}
}

void delay(unsigned char x)
{
	unsigned char i, j;
	for (i = 0; i < x; i ++)
		for (j = 0; j < 100; j ++);
}
