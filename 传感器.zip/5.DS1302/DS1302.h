#ifndef __DS1302_H_
#define __DS1302_H_

sbit DS1302_SCK=P2^2;
sbit DS1302_SDA=P2^1;
sbit DS1302_RST=P2^0;
extern unsigned char timer[8];
#define BCDTODEC(bcd) ((bcd)=((bcd)&0x0f)+((bcd)>>4)*10)
#define DECTOBCD(bcd) ((bcd)=(bcd+(bcd/10)*6))



void WDS1302(unsigned char temp);
void WDS1302_Byte(unsigned char address,unsigned char dat);
unsigned char RDS1302_Byte(unsigned char address);
void ds1302_init();
void ds1302_read();



#endif 

