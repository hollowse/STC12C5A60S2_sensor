#include <STC12C5A60S2.h>
#include <intrins.h>
#include "delay.h"
uint key = 0;

unsigned int key_scan()
{
	unsigned int Row,Col;
	P0 = 0x0f;
	
	if(P0 != 0x0f)
	{
		delay1ms(10);
		if(P0 != 0x0f)
		{
			Row = P0 & 0x0f;
			P0 = 0xf0;
			Col = P0 & 0xf0;
		}
//		while((P0 & 0xf0) != 0xf0);
	}
	switch(Row+Col){
		case 0xe7:key=1;break;
		case 0xd7:key=2;break;
		case 0xb7:key=3;break;
		case 0x77:key=4;break;

		case 0xeb:key=5;break;
		case 0xdb:key=6;break;
		case 0xbb:key=7;break;
		case 0x7b:key=8;break;

		case 0xed:key=9;break;
		case 0xdd:key=10;break;
		case 0xbd:key=11;break;
		case 0x7d:key=12;break;

		case 0xee:key=13;break;
		case 0xde:key=14;break;
		case 0xbe:key=15;break;
		case 0x7e:key=16;break;

	}
	return key;
}
	