#include <STC12c5a60s2.h>
#include <intrins.h>
#include "Nixie.h"
#include "delay.h"
unsigned char code num_lib[]={0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f,0x77,0x7c,0x39,0x5e,0x79,0x71};   //0-9,ABCDEF�������������

void start_IIC()
{
    CLK=1;
    DIO=1;
    delay(1);
    DIO=0;
    delay(1);
    CLK=0;
    delay(1);
}

void stop_IIC()
{
    CLK=1;
    DIO=0;
    delay(1);
    DIO=1;
}

void ack_IIC()   
{
    CLK=0;
    delay(1);
    while(DIO);
    CLK=1;
    delay(1);
    CLK=0;
}

void WriteByte(unsigned char WriteData) 
{
    unsigned char i;
    for(i=0;i<8;i++) 
    {
        CLK=0;
        delay(1);
        WriteData=WriteData>>1;
        DIO=CY;
        delay(1);
        CLK=1;
        delay(1);
    }
		ack_IIC(); 
}

void WSROM(unsigned char addr,unsigned char WData)
{
    start_IIC(); 
    WriteByte(addr); 
    WriteByte(WData);
    stop_IIC();
}

void disply_led(unsigned char qian,unsigned char bai,unsigned char shi,unsigned char ge)
{
    DIO=1;
		CLK=1;
				start_IIC();
		WriteByte(0x44); 
		stop_IIC();
		WSROM(0xC0,num_lib[qian]);
		WSROM(0xC1,num_lib[bai]);  
		WSROM(0xC2,num_lib[shi]);
		WSROM(0xC3,num_lib[ge]);   
				delay(1);
				start_IIC();
		WriteByte(0x8a);  
		stop_IIC();        
}
