#include <STC12C5A60S2.H>
#include	"intrins.h"
#include "lcd12864.h"
#include "delay.h"
#include "Nixie.h"

void main()
{
	PSB = 0;
	lcdinit();
	
	delay1ms(1);
	
	while(1) 
	{ 
		disply_led(2,6,2,1);	
		dis (2,1,"TM1637");
		
	}
}

