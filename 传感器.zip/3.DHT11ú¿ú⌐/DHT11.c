#include <STC12C5A60S2.H>
#include <stdio.h>
#include "intrins.h"
#include "delay.h"
#include "DHT11.H"
#include "LCD12864.h"

uint RH,RL,TH,TL; 
uchar s[32],p[32];
uchar R_H,R_L,T_H,T_L,revise;

void DHT11_start()
{
   Data=1;
   delay10us(1);
   Data=0;
   delay1ms(20);
   Data=1;
   delay10us(6);
}

uchar DHT11_rec_byte()
{
   uchar i,dat=0;
  for(i=0;i<8;i++) 
   {          
      while(!Data);  
      delay10us(6); 
      dat<<=1;   
      if(Data==1)  
         dat+=1;
      while(Data); 
    }  
    return dat;
}

void DHT11_receive()   
{
    DHT11_start();
    if(Data==0)
    {
        while(Data==0);     
        delay10us(8);
        R_H=DHT11_rec_byte(); 
        R_L=DHT11_rec_byte(); 
        T_H=DHT11_rec_byte(); 
        T_L=DHT11_rec_byte();
        revise=DHT11_rec_byte(); 

        delay10us(5); 

        if((R_H+R_L+T_H+T_L)==revise) 
        {
            RH=R_H;
            RL=R_L;
            TH=T_H;
            TL=T_L;
        } 
    }
}

void dis_DHT11()
{
		DHT11_receive();
		sprintf(s,"�¶ȣ�%d",TH);
		dis (1,1,s);
		sprintf(p,"ʪ�ȣ�%d",RH);
		dis (2,1,p);
}
