#include <STC12C5A60S2.H>
#include "intrins.h"
#include "delay.h"
#include "LCD12864.h"
#include "DHT11.h"

void main()
{
	PSB = 0;
	lcdinit();
	delay10us(1);
	while(1)
	{
		dis (4,1,"��");
		dis_DHT11();
		dis (3,2,"��");
	}
	
}