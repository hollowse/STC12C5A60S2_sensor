#ifndef __DHT11_H_
#define __DHT11_H_

sbit Data = P2^0;

void DHT11_start();

unsigned char DHT11_rec_byte();
void DHT11_receive();
void dis_DHT11();

#endif
