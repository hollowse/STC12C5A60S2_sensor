#ifndef __UART_H_
#define __UART_H_

void UartInit(void);		//9600bps@11.0592MHz
void outchar(char ch);
void prints(char *s);



#endif 