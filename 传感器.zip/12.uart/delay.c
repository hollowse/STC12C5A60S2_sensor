#include <STC12C5A60S2.H>
#include "intrins.h"



void delay1ms(unsigned char x)		//@11.0592MHz
{
	unsigned char i, j;
	while(x--){
	_nop_();
	i = 11;
	j = 190;
	do
	{
		while (--j);
	} while (--i);
	}
}
