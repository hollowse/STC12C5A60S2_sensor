#include <STC12C5A60S2.H>
#include "uart.h"
#include "delay.h"
#include <stdio.h>

sbit light = P2^0;
unsigned char voice_flag = 0;
void main()
{
	UartInit();
	
	delay1ms(1);
	while(1)
	{
		if (light == 0)		
		{
			voice_flag = 0;
			if (voice_flag == 0)
			{
				prints("����");
				voice_flag = 1;
			}
			delay1ms(200);
		}
//		else
//				prints("���");
			
	}
	
}