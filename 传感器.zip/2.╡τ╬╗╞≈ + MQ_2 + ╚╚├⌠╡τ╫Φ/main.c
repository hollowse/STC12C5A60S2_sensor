#include "intrins.h"
#include <STC12C5A60S2.H>
#include <stdio.h>
#include "delay.h"
#include "lcd12864.h"
#include "ADC.H"


uchar s[16];
uint adc;

void main()
{
	PSB = 0;
	lcdinit();
	AD_init();
	delay(10);
	dis (1,1,"AD�ɼ���ѹֵ");
	while(1)
	{
		adc = light(Get_AD(0));					//P17
		sprintf(s,"����ֵ��%d",adc);
		dis (2,6,"      ");
		dis (2,1,s);
		
//		adc = Get_AD(6);					//P16
//		sprintf(s,"������%d",adc);
//		dis (3,5,"      ");
//		dis (3,1,s);
//		
//		adc = temp(Get_AD(0));			//P10
//		sprintf(s,"�¶ȣ�%d",adc);
//		dis (4,5,"      ");
//		dis (4,1,s);
		
		delay1ms(100);
		
	}
	
}
