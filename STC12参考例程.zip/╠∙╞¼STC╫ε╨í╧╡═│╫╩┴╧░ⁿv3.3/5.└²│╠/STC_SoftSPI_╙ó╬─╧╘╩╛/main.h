#ifndef __MAIN__H__
#define __MAIN__H__

#include <reg52.h>


void Display_Desc();



#endif